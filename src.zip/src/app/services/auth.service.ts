import { Injectable, OnInit, OnDestroy, OnChanges } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Elemento } from '../interfaces/element.interface';
import { ElementId } from '../interfaces/element.interface';
import { map } from 'rxjs/operators';
import { environment } from '../../environments/environment';
import { Router } from '@angular/router';
import { auth } from 'firebase';




@Injectable({
  providedIn: 'root'
})
export class AuthService  implements OnInit, OnChanges {
  // create new user
  // https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyCustomToken?key=[API_KEY]
  // sigin user password
  // https://www.googleapis.com/identitytoolkit/v3/relyingparty/verifyPassword?key=[API_KEY]
  // api key = AIzaSyBcPkO9oiGpfYaBUgfg2vsKvDdJdFYUOko

  private url = 'https://www.googleapis.com/identitytoolkit/v3/relyingparty';
  //private key = 'AIzaSyBcPkO9oiGpfYaBUgfg2vsKvDdJdFYUOko';
  //private for svc = AIzaSyC-Dl8nAJlY_Po_IdFvBEuwcNxTC9ieG88
  private key = 'AIzaSyBEYZHKcxCSAdhL62J-P4-kqobb4v4zFGY';
  private userToken = '';
  private urlSVC:string = environment.serviceURL;
  private user: ElementId;
  userTypes = [];
  currentUser: ElementId = null;
  private esAdministrador:boolean = false;
  private esUsuario:boolean = false;
  private esSuperAdministrador: boolean = false;
  constructor(private http: HttpClient, private router: Router) { 
    this.leertoken();
    //this.currentUser = JSON.parse(localStorage.getItem("user"));
        //this.esAdministrador = this.isSupAdmin();
  }
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
   // console.log("onchanges service: " +this.currentUser);
  }
  ngOnInit(): void {
    
   // console.log("oninitService: " +this.currentUser);
  }
  
  logout() {
    localStorage.removeItem('token');
    this.userToken = '';
    this.clearLevels();
    this.currentUser = null;
    localStorage.removeItem('user');
    localStorage.removeItem('group');
    
  }
  setUser(user: ElementId){
    localStorage.setItem('user',JSON.stringify(user));
   this.currentUser = user;
   this.setLevel();
  }
  getUser(){
    this.currentUser = JSON.parse(localStorage.getItem('user'));
    this.currentUser? this.setLevel():null;
    return this.currentUser;
  }
  login(user: Elemento) {
    const authData = {
      email : user.email,
      password : user.password,
      returnSecureToken : true
    };
    //console.log("sending: "+authData.email+" "+authData.password);
    return this.http.post(
      `${ this.url }/verifyPassword?key=${ this.key }`,
      authData
    ).pipe(
      map( resp => {
        this.guardarToken(resp['idToken']);
        localStorage.setItem("uid: ",resp["localId"]);
        //this.user.password = "";
        this.setUser(resp);
        //console.log("GUARDANDO USER: "+ JSON.stringify(this.currentUser));
        
        return resp;
      })
    );
  }
  nuevousuario(user: ElementId) {
    
    const authData = {
      type: user.type,
      email : user.email+user.type,
      password : user.password,
      displayName: user.displayName,
      phoneNumber: user.phoneNumber,
      returnSecureToken : true,
      grupo: user.name? user.name:"",
      token: user.tokn? user.tokn:"",
      uid: user.uid? user.uid:""
    };
  console.log('ENVIANDO displayName '+JSON.stringify(authData));
    
   return this.http.post<ElementId>(
     // `${ this.url }/signupNewUser?key=${ this.key }`,
     this.urlSVC+"/newuser",
      authData
    ).pipe(
      map( resp => {
       
       console.log("respuesta al insertar usuario: "+JSON.stringify(resp));
        return resp;
      })
    );
  }

 
  private guardarToken( idToken: string) {
     this.userToken = idToken;
     localStorage.setItem('token', idToken);
    //console.log("TOKEN: "+localStorage.getItem('token'));
  }
  leertoken() {
    if ( localStorage.getItem('token')) {
      //console.log("TOKEN: "+localStorage.getItem('token'));
       this.userToken = localStorage.getItem('token');
    } else {
      this.userToken = '';
    }

    return this.userToken;
  }
  estaAutenticado(): boolean {
   return this.userToken.length > 2;
  }
  getProfileTypes(user: string) {
    const authData = {
      id: user
    };
    //console.log("sending: "+ authData.id);
    
    return this.http.post<ElementId[]>(
      // `${ this.url }/signupNewUser?key=${ this.key }`,
      this.urlSVC+"/getProfileTypes",
       authData
     ).pipe(
       map( resp => {
        //this.user = resp;
         return resp;
       })
     );
   }

  isSupAdmin() {
    return this.esSuperAdministrador;
  }
  isAdmin() {
    return this.esAdministrador;
  }
  isUser() {
    return this.esUsuario;
  }
  clearLevels(){
  this.esSuperAdministrador = false;
        this.esAdministrador = false;
        this.esUsuario = false;
  }
  setLevel(){
    let splittedEmail = this.currentUser.email ? this.currentUser.email.split('@')[1].split('.')[0]:'user';
    switch (splittedEmail) {
      case 'supadmin':
        //console.log("seteando supadmin:" + splittedEmail);
        this.esSuperAdministrador = true;
        break;
      case "admin":
      case "tech":
      case "vendor":
       // console.log("seteando admin:" + splittedEmail);
        this.esAdministrador = true;
        break;
      case 'user':
        //console.log("seteando user:" + splittedEmail);
        this.esUsuario = true;
        break;
      default:
       // console.log("seteando user:" + splittedEmail);
        this.esUsuario = true;
        break;
    }
  }
  isOwner(user: ElementId){
    if(user.owner === "owner")
    {
      return true;
    }
    return false;
  }
  getdisplayName() {
    return this.currentUser ? this.currentUser.displayName : "Usuario";
  }
  getUserLevels(group: string) {
    this.userTypes = [];
    
    const level = this.currentUser.type.split('.')[0];
   // const group = this.currentUser.type.split('.')[1]
   // console.log("USUario"+ this.currentUser.type+" level: "+level+" group: "+group);
    if(level == "@tech" || this.currentUser.type == "@vendor"){
      this.userTypes.push({id: '@user.'+group, name: 'Usuario'});
    }
    if(level == "@admin"){
      this.userTypes.push({id: '@vendor.'+group, name: 'Vendedor'});
      this.userTypes.push({id: '@tech.'+group, name: 'Técnico'});
      this.userTypes.push({id: '@user.'+group, name: 'Usuario'});
    }
    if(level == "@supadmin"){
      
      this.userTypes.push({id: '@supadmin.'+group, name: 'SuperAdministrador'});
      this.userTypes.push({id: '@admin.'+group, name: 'Administrador'});
      this.userTypes.push({id: '@tech.'+group, name: 'Técnico'});
      this.userTypes.push({id: '@vendor.'+group, name: 'Vendedor'});
      this.userTypes.push({id: '@user.'+group, name: 'Usuario'});
    }
    //this.userTypes.unshift({id:'@user.com',name: 'Usuario'});
    console.log("usertypes: "+JSON.stringify(this.userTypes));
    return this.userTypes;
  }
}
