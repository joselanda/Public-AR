import { Injectable } from '@angular/core';
import { ElementId, Template } from '../interfaces/element.interface';
import { AfsService } from './afs.service';

@Injectable({
  providedIn: 'root'
})
export class ResourcesService {
public currentGroup:ElementId;
private currentNote: ElementId = null;
private template:ElementId;
  constructor(private afService: AfsService) { 
    this.currentGroup = {};
    this.template = {} as Template;
  }
  setGroup(element: ElementId) { 
    localStorage.setItem('group',JSON.stringify(element));
    this.currentGroup = element; }

  getGroupArray(element:string=''): ElementId[] | ElementId | string { 
    this.currentGroup = JSON.parse(localStorage.getItem('group'));
    switch (element) {
      case 'elements':
        return this.currentGroup.elements ? this.currentGroup.elements : [];
      case 'users':
        return this.currentGroup.users ? this.currentGroup.users : [];
      case 'areas':
        return this.currentGroup.areas ? this.currentGroup.areas : [];
      case 'subcategories':
        return this.currentGroup.subcategories ? this.currentGroup.subcategories : [];
      case 'categories':
        return this.currentGroup.categories ? this.currentGroup.categories : [];
      case 'name':
        return this.currentGroup.type ? this.currentGroup.type : '';
        case 'templateCat':
        return this.currentGroup.template ? this.currentGroup.template[0] : '';
        case 'templateSubCat':
        return this.currentGroup.template ? this.currentGroup.template[1] : '';
        case 'templateElem':
        return this.currentGroup.template ? this.currentGroup.template[2] : '';
      default:
        return this.currentGroup;
    }
  
  }
  getGroupFromDB(group:ElementId){
    //console.log("getting: "+JSON.stringify(group));
    let promise = 
      this.afService.doc$<ElementId>(`groups/${group.id}/groups/${group.name}`);
    return promise;
  }
  compare(a: ElementId, b:ElementId) {
    //comparing the elements by order number
   const first = a.orden;
   const second = b.orden;
 
   let comparison = 0;
   if (first > second) {
     comparison = 1;
   } else if (first < second) {
     comparison = -1;
   }
   return comparison;
 }
  clearGroup() { this.currentGroup = {} }

  getTemplate(){ return this.template }

  setCurrentNote(note: ElementId){
    this.currentNote = note;
  }
  getCurrentNote(){
    return this.currentNote;
  }


}
