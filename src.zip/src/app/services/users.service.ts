import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Elemento } from '../interfaces/element.interface';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { ElementId } from 'src/app/interfaces/element.interface';
import { environment } from '../../environments/environment';
import { AfsService } from './afs.service';

@Injectable({
  providedIn: 'root'
})

export class UsersService {
  private url:string = environment.serviceURL;
  private currentUser:ElementId = null;
 // private url = "http://localhost:5000/apisvc/us-central1/api";
  constructor(private http: HttpClient, private afs: AfsService) { 
    
    
  }

 
  //#region get users
  getUsers(enabled:string, type:string) {
    
console.log("type sending: "+type+" enabled" +enabled);
    return this.http.post<ElementId[]>(this.url + '/getusers/',{enabled:enabled, type:type}).pipe(
      map( resp => {
      //console.log('entro en el map()');
      return resp;
    }));
  }
  
//# Get User by
  getUsuarioByEmail(email: string) {
    const authData = {
      email : email
    };

    return this.http.post<ElementId>(
     // `${ this.url }/signupNewUser?key=${ this.key }`,
     this.url + '/getUserByEmail',
      authData
    ).pipe(
      map( resp => {
       
        return resp;
      })
    );
  }

  getUsuarioByNumber(phone: string){
    //const query = (ref) => ref.where('id', "==", 'meximedia');
    const element =  this.afs.doc$<ElementId>('/users/'+phone);
   return element;
  }

 //# region delete user
 deleteUser(user: ElementId) {
    
  var authData = {
    uid: user.id,
    email:user.email
  };
  console.log('ELIMINANDO displayName '+authData.email+" PHONE: "+authData.email
  +" UID: "+authData.uid);
  return this.http.post<ElementId>(
   // `${ this.url }/signupNewUser?key=${ this.key }`,
   this.url + '/deleteUser',
    authData
  ).pipe(
    map( resp => {
    //  console.log('RECIBIENDO USUARIO --> '+user.displayName+" "+resp.disabled+" "+resp.email+" "+resp.phoneNumber
      //+" "+resp.emailVerified+" "+resp.password+" "+resp.photoURL+" "+resp.uid);
      //this.guardarToken( resp['idToken']);
      return resp;
    })
  );
}
  //# Update User 
  updateUser(user: ElementId) {
    
    var authData = {
      uid: user.uid,
      email: user.email,
      phoneNumber: user.phoneNumber,
      emailVerified: user.emailVerified,
      password: user.password,
      displayName: user.displayName,
      photoURL: user.photoURL,
      disabled: user.disabled
    };
    console.log('ENVIANDO displayName '+authData.displayName+" DISABLED: "
    +authData.disabled+" EMAIL: "
    +authData.email+" PHONE: "+authData.phoneNumber
    +" "+authData.emailVerified+" PASSWORD: "+authData.password+" PHOTO: "
    +authData.photoURL+" UID: "+authData.uid);
    return this.http.post<ElementId>(
     // `${ this.url }/signupNewUser?key=${ this.key }`,
     this.url + '/editUser',
      authData
    ).pipe(
      map( resp => {
      //  console.log('RECIBIENDO USUARIO --> '+user.displayName+" "+resp.disabled+" "+resp.email+" "+resp.phoneNumber
        //+" "+resp.emailVerified+" "+resp.password+" "+resp.photoURL+" "+resp.uid);
        //this.guardarToken( resp['idToken']);
        return resp;
      })
    );
  }
  
}
