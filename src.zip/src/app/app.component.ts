import { Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router'

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'PubliCasTV';
  mostrar = true;
  frase: any = {
    mensaje: 'gran poder',
    autor: 'gran responsabilidad'
  };
  getUrl(){
    return "url('https://firebasestorage.googleapis.com/v0/b/italo-cf94a.appspot.com/o/file%20%2Fweb.png?alt=media&token=1ec3ce45-987a-4acc-8527-4e9cd3342563')";
  }
}
