import { Component, OnInit, Input, Output, EventEmitter, OnChanges, ViewChild, ElementRef, AfterViewInit  } from '@angular/core';
  import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';
  import { ValidadoresService } from '../../../services/validadores.service';
  import { ElementId, Elemento, Template } from '../../../interfaces/element.interface'
  import {Router} from '@angular/router';
import { UsersService } from 'src/app/services/users.service';
import Swal from 'sweetalert2';
import { ElementsService } from 'src/app/services/elements.service';
import { FileModel } from 'src/app/models/file.model';
import { AfsService } from 'src/app/services/afs.service';

@Component({
  selector: 'app-newelement',
  templateUrl: './newelement.component.html',
  styleUrls: ['./newelement.component.css']
})
export class NewelementComponent implements OnInit, OnChanges, AfterViewInit  {
  ngAfterViewInit(): void {
    //console.log(this.userPhone.nativeElement.innerHTML);
  }


  @Input() type: string;
  @Input() item: ElementId;
  @Input() area: string;
  @Output() addItem: EventEmitter<Elemento>;
  @ViewChild('nameSearch') userPhone: ElementRef;
  @ViewChild('productToSearch') productName: ElementRef;
  @ViewChild('toggle') toggle: ElementRef;
  templateElement: Template= {} as Template;
  ngClass = 'col-sm-12 col-lg-12 m-t-5 m-b-5';
  currentUser:ElementId;
  user:boolean = false;
  note: boolean = false;;
  product:boolean = false;
  service:boolean = false;
  group: boolean = false;
  addImage: boolean = false;
  addUser: boolean = false;
  currentElement: ElementId = {images:[], users:[],elements:[]};
  currentTemplate: ElementId;
  archivos: FileModel[] = [];
  elements: ElementId[];
  objectKeys: string[];
  currentItem: ElementId={};
  nameEnabled=false;
   tipo: string="hola";
    forma: FormGroup;
    itemToSearch = 'Product or service';
  editComponent = false;
    element: Elemento;
    caller: string = 'Nuevo Elemento';
    constructor( private fb: FormBuilder, private elementService: ElementsService, private afsService: AfsService,
                 private validadores: ValidadoresService,private router: Router, private userSvc: UsersService ) { 
                  this.router.events.subscribe((e: any) => {
                    //console.log('Router event:', e);
                  });
                  this.addItem = new EventEmitter<Elemento>();
      //this.cargarDataAlFormulario();
      //this.crearListeners();
  
    }
    ngOnInit(): void {
      this.currentUser = JSON.parse(localStorage.getItem('user'));
      this.element = this.item as Elemento;
      this.item.total = 0;
      this.unableAddings();
      if(this.type == 'Nueva Nota'){
        this.ngClass = 'col-sm-12 col-lg-6 m-t-5 m-b-5';
        this.item.elements != undefined ? this.item.elements : [];
        this.item.images != undefined ? this.item.images : [];
        this.item.users != undefined ? this.item.users : [];
        this.item.comments != undefined ? this.item.comments : [];
        this.item.elements ? this.calculateTotal():null;
      }else{
        this.item.elements == undefined;
        this.item.users == undefined;
      }
     
      this.objectKeys = Object.keys(this.templateElement);
      //console.log("objectKeys: "+JSON.stringify(this.objectKeys));
     //console.log("elemento recibido"+ JSON.stringify(this.item)+" y type "+this.type);
     this.crearFormulario();
    }
    ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
     //console.log("onchanges NEW ELEMENT: "+JSON.stringify(changes));
     console.log("this.type: "+this.type);
     console.log("this.area: "+this.area);
      this.unableAddings();
     
      this.crearFormulario();
      //console.log("disable name: "+this.nameEnabled)
      if(this.type == 'edit'){
      this.nameEnabled = this.forma.get('name').value != '' ?true:false;
      }else{
        this.nameEnabled = false;
      }
      
    }
    setType(type: string){
      //this.currentElement = null;
      this.currentTemplate = type =='image' ?{title:'',description:'',images:[]}:{comments:[]};
      this.caller= type =='image' ?'Nueva Imagen':'Nuevo Comentario';
      this.editComponent = true;
    }
    unableAddings(){
      if(this.area == 'notas')
      { 
        this.product = false;
        this.service = false;
        this.user = false;
      }else if(this.area == 'productos'){
       this.note = false;
       this.product = true;
       this.service = false;
       this.user = false;
      }else if(this.area == 'user'){
       this.product = false;
       this.note = false;
       this.service = false;
       this.user = true;
      
     }else if(this.area == 'servicios'){
       this.product = false;
       this.note = false;
       this.service = true;
       this.user = false;
      }
    }

    insertItem(item:ElementId){
     let oldElement = this.elements.find(e => e.id == item.id);
     //console.log("old element: "+JSON.stringify(oldElement));
     oldElement = item;
     //console.log("new element: "+JSON.stringify(oldElement));
     //console.log("new item: "+JSON.stringify(item));
     this.updateElement(item);
    }
    setCurrentElement(element: ElementId){
      this.editComponent = false;
    this.currentItem = element;
    }
    updateElement(item:ElementId){
      this.item.elements == null ? this.item.elements = [] : null;
      let pushOrNot = true;
      this.item.elements.forEach(element => {
        if(element.name == item.name){
          pushOrNot = false;
          let cantTotal = element.cantidad + item.cantidad;
          cantTotal <= item.stock ? element.cantidad = cantTotal:null;
          this.calculateTotal();
        }
      });
      pushOrNot ? this.item.elements.push(item):null;
     // (<HTMLInputElement> document.getElementById("agregarBtn")).click();
      //console.log('Update product: '+JSON.stringify(item));
      this.elements = null;
      this.calculateTotal();
      
    }
    addOneImage(item: ElementId){
      switch (this.caller) {
        case 'Nueva Imagen':
          console.log("nueva imagen: "+JSON.stringify(item));
          this.item.images == null ? this.item.images = [] : null;
      item.images.forEach(image => {
        this.item.images.push(image);
      });
          break;
          case 'Nuevo Comentario':
            console.log("nuevo comentario: "+JSON.stringify(item));
            this.item.comments == null ? this.item.comments = [] : null;
            this.item.comments.push({title:item.title,owner:this.currentUser.displayName,description:item.description});
            console.log("Item mas comentarios: "+JSON.stringify(this.item))
          break;
          
        default:
          break;
      }
      
     
     // console.log("RECIBIENDO: "+JSON.stringify(item));
      (<HTMLInputElement> document.getElementById("dismissModal")).click();
    }
    deleteProduct(element:ElementId){
      
      this.item.elements.splice(this.item.elements.findIndex(e => e.name === element.name),1);
      
      this.calculateTotal();
    }
    calculateTotal(){
      this.item.total = 0;
      this.item.elements.forEach(element => {
        //console.log("subtotal element:"+element.subtotal);
        this.item.total += element.subtotal; 
      });
    }
    deleteImage(element:ElementId){
      this.item.images.splice(this.item.images.findIndex(e => e.name === element.name),1);
     // console.log("DELETING IMAGES: ");
     // this.item.images = [];
    }
    borrarElementos() {
      document.getElementById('file').removeAttribute('value');
      this.archivos = [];
      this.item.images = [];
    }
   
    formReset(){
      this.forma.reset();
      this.item.elements = [];
      this.item.images = [];
      this.item.users = [];
      this.clearSearch();
      this.item.total = 0;
    }
    crearFormulario() {
      this.forma = this.fb.group({ });
      //ading default fields to form name and description
      this.item.name !== undefined ? this.addTextInput('name',this.item.name != null ?this.item.name : ""):null;
      this.item.description !== undefined? this.addTextInput('description',
      this.item.description != null ?this.item.description : ""):null;
      this.item.status !== undefined ? this.agregarStatus(): null;

    
         // this.note = true;
          this.item.users !== undefined && this.item.users[0] ? this.agregarUser(this.item.users[0]): null;
      
          //this.product = true;
          
          this.item.stock !== undefined ? this.addNumberInput('stock',
      this.item.stock != null ?this.item.stock : null):null;

      this.item.ventas !== undefined ? this.addNumberInput('ventas',
      this.item.ventas != null ?this.item.ventas : null):null;

      this.item.precioVta !== undefined ? this.addNumberInput('precioVta',
      this.item.precioVta != null ?this.item.precioVta : null):null;

      this.item.precioCompra !== undefined ? this.addNumberInput('precioCompra',
      this.item.precioCompra != null ?this.item.precioCompra : null):null;
      this.item.imei !== undefined ? this.addNumberInput('imei',
      this.item.imei != null ?this.item.imei : null):null;
  
          //this.service = true;
         

         // this.user = true;
          this.item.displayName != undefined ? this.addTextInput('displayName',
      this.item.displayName != null ?this.item.displayName : ''):null;
          this.item.password !== undefined? this.agregarPassword():null;

          //this.group = true;
          this.item.password != undefined? this.agregarPassword():null;

          
 }
 setItemToSearch(itemToSearch: string){
  
   this.itemToSearch = itemToSearch;
   this.clearSearch();
   //console.log('setting itemtosearch: '+this.itemToSearch);
 }
 getItem(){
  let inputValue = this.productName.nativeElement.value;
  switch(this.itemToSearch){
    case 'Product or service':
      this.getProductByDesc(inputValue);
    break;
    case 'Phone User':
      this.getUsuarioByPhone(inputValue)
      break;
  }
  return false;
 }
//OBTENIENDO CLIENTE PARA AGREGARLOS AL ITEM
getProductByDesc(productName: string) {
console.log('value to search: '+productName);
  // fetch value
  let keyValues: string[] = this.productName.nativeElement.value.split(" ");
  let inputValue = keyValues[0];
 // console.log('sending: ' + JSON.stringify(keyValues));
/// const query = (ref) => ref.where('name', "==", inputValue);

const query = (ref) => ref.where('hastags', "array-contains", inputValue);
this.afsService.col$('products',query).subscribe(res=>{
   this.elements = res;
 });
 this.clearSearch();
}
clearSearch(){
  this.productName.nativeElement.value = '';
  this.elements = [];
}
  getUsuarioByPhone(userPhone:string) {

    // fetch value
   // let inputValue = this.userPhone.nativeElement.value;
   // console.log('sending: ' + inputValue)
    this.userSvc.getUsuarioByNumber(userPhone).subscribe(res => {
     // console.log("res " + JSON.stringify(res));
      if (res !== undefined) {
        this.item.users = [];
        this.item.users.push({
          name: res.displayName,
          phoneNumber: res.phoneNumber
          
        });
        this.currentElement.name = res.phoneNumber.substring(2, res.phoneNumber.length);
        //(<HTMLInputElement> document.getElementById("productToSearch")).innerHTML = '';
        this.clearSearch();
      }
      else {
        Swal.fire({
          type: 'error',
          title: 'Usuario no encontrado',
          text: "No encontramos información sobre ese usuario"
        });
      }

    });
  }

    //GETTING BOOLEANS
    get addingUser(){
      
      return this.addUser;
    }
    get addingImage(){
      
      return this.addImage;
    }
    get newUser() {
      return this.user;
    }
    get newGroup() {
      return this.group;
    }
    get newProduct() {
      return this.product;
    }
    get newService() {
      return this.service;
    }
    get newNote() {
      return this.note;
    }
  
    get nombreNoValido() {
      return this.forma.get('name').invalid && this.forma.get('name').touched
    }
    get displayNameNoValido() {
      return this.forma.get('displayName').invalid && this.forma.get('displayName').touched
    }
    get descriptionNoValido() {
      return this.forma.get('description').invalid && this.forma.get('description').touched
    }
  
    get correoNoValido() {
      return this.forma.get('email').invalid && this.forma.get('email').touched
    }
  
    get stockNotValid() {
      return this.forma.get('stock').invalid && this.forma.get('stock').touched
    }
    get ventasNotValid() {
      return this.forma.get('ventas').invalid && this.forma.get('ventas').touched
    }
  
    get precioVtaNotValid() {
      return this.forma.get('precioVta').invalid && this.forma.get('precioVta').touched
    }
    get imeiNotValid() {
      return this.forma.get('imei').invalid && this.forma.get('imei').touched
    }
    get precioCompraNotValid() {
      return this.forma.get('precioCompra').invalid && this.forma.get('precioCompra').touched
    }
  
    get ciudadNoValido() {
      return this.forma.get('direccion.ciudad').invalid && this.forma.get('direccion.ciudad').touched
    }
  
    get pass1NoValido() {
      return this.forma.get('password').invalid && this.forma.get('password').touched;
    }
  
    get pass2NoValido() {
      const pass1 = this.forma.get('pass1').value;
      const pass2 = this.forma.get('pass2').value;
  
      return ( pass1 === pass2 ) ? false : true;
    }

  //ADDING FIELDS
    agregarPassword(){
      this.forma.setControl('password',this.fb.control('',[Validators.required,Validators.minLength(6)]));
    }
    addTextInput(field: string, value: string){
      
       
      // console.log("nameEnabled: "+this.nameEnabled)
      this.forma.setControl(field,this.fb.control(value,[Validators.required,Validators.minLength(6)]));
    }
    addNumberInput(field: string, value: number){
      this.forma.setControl(field,this.fb.control(value,[Validators.required,Validators.min(0), Validators.max(1000000000000000)]));
    }
    agregarName(){
      let enabled = this.item.name !== ''? true:false;
      this.forma.setControl('name',this.fb.control({value:this.item.name, disabled: enabled},[Validators.required,Validators.minLength(6)]));
    }
    
    agregarStatus(){
      this.forma.setControl('status',this.fb.control(this.item.status,[Validators.required,Validators.minLength(6)]));
    }
    agregarImei(){
      this.forma.setControl('imei',this.fb.control(this.item.imei,[Validators.required,Validators.minLength(6)]));
    }
    agregarUser(user: ElementId){
      this.forma.setControl('users',this.fb.group(user));
    }

    //DELETINGS CONTROLS
    deleteControl(element: string){
      this.forma.removeControl(element);
    }
    deleteUser(){
     // console.log("DELETING USERS: ");
      this.item.users.pop();
    }
  
    crearListeners() {
      // this.forma.valueChanges.subscribe( valor => {
      //   console.log(valor);
      // });
  
      // this.forma.statusChanges.subscribe( status => console.log({ status }));
     // this.forma.get('nombre').valueChanges.subscribe( console.log );
    }
  
    cargarDataAlFormulario() {
  
      // this.forma.setValue({
      this.forma.reset({
        nombre: 'Fernando',
        apellido: 'Perez',
        correo: 'fernando@gmail.com',
        pass1: '123',
        pass2: '123',
        direccion: {
          distrito: 'Ontario',
          ciudad: 'Ottawa'
        },
      });
  
    }
  
  
    agregarPasatiempo() {
      //this.pasatiempos.push(  this.fb.control('')  );
    }
    
    borrarPasatiempo(i: number) {
      //this.pasatiempos.removeAt(i);
    }
  
  
    guardar() {
      console.log( this.forma );
      //this.element.password = "password";
      if ( this.forma.invalid ) {
       // console.log( "invalid form" );
        return Object.values( this.forma.controls ).forEach( control => {
          
          if ( control instanceof FormGroup ) {
            Object.values( control.controls ).forEach( control => control.markAsTouched() );
          } else {
            control.markAsTouched();
          }
          
          
        });
       
      }
      if(this.type == 'Nueva Nota'){
        if(this.item.elements.length == 0){
          let legend = this.item.elements.length == 0 ? "Agrega un Producto o servicio":"";
          (<HTMLInputElement> document.getElementById("errLbl")).innerHTML = legend;
          //console.log( "validating elements and users" );
         
          return null;
        }
         
        this.currentElement.images = this.item.images;
        this.currentElement.users = this.item.users;
        this.currentElement.total=0;
        console.log("comments item"+JSON.stringify(this.item.comments));
        this.currentElement.comments = this.item.comments;
        
        this.item.elements.forEach(element => {
         // console.log("foreach element : "+JSON.stringify(element));
          this.currentElement.elements.push({
          name : element.name,
          description : element.description,
          url : element.url,
          cantidad : element.cantidad,
          subtotal: element.subtotal
          })
          
          this.currentElement.total += element.subtotal; 
         });
         //this.currentElement.name = this.forma.get('name').value;
         this.currentElement.name = this.currentElement.name == undefined ? '' : this.currentElement.name;
         this.currentElement.description = this.forma.get('description').value;
         this.addItem.emit(this.currentElement);
         //console.log("emiting item: "+JSON.stringify(this.item))
         //console.log( "emiting forma.value" +JSON.stringify(this.forma.value));
         //console.log( "emiting currentElement" +JSON.stringify(this.currentElement));
      }else{
        
        //this.item.images ? this.forma.setControl('images',this.fb.group(this.item.images)):null;
       // this.nameEnabled ? this.forma.setControl('name',this.fb.control(this.currentElement.name)):null;
        this.item.id ? this.addItem.emit(this.item):this.addItem.emit(this.forma.value);
       // console.log( "emiting item" +JSON.stringify(this.item));
        //console.log( "emiting forma.value" +JSON.stringify(this.forma.value));
        //console.log( "emiting currentElement" +JSON.stringify(this.currentElement));
      }
     
      
      // Posteo de información
      this.forma.reset();
      this.item.elements =[];
      this.item.users =[];
      this.item.images =[];
  
    }
  
  }
  