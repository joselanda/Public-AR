import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { Elemento } from '../../../interfaces/element.interface';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { AfsService } from 'src/app/services/afs.service';
import { Observable } from 'rxjs';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { ElementId } from '../../../interfaces/element.interface'
import { ResourcesService } from 'src/app/services/resources.service';

@Component({
  selector: 'app-registro',
  templateUrl: './registro.component.html',
  styleUrls: ['./registro.component.css']
})
export class RegistroComponent implements OnInit, OnChanges {
  user: ElementId = {type:'@user.com'} as ElementId;
  currentUser: ElementId = null;
  recordarme = false;
  registroNuevo: boolean = false;
  userTypes = null;
  supadminAdd = false;

  ref: AngularFirestoreCollection<ElementId>;
  elements: Observable<ElementId[]>;
  group: ElementId;
  @Input() type: string;
  @Input() item: ElementId;


  constructor(public authService: AuthService, private resService: ResourcesService,
              private router: Router, private afserv: AfsService, private afs: AngularFirestore) {
                
  }
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    this.currentUser !== null ? this.userTypes = this.authService.getUserLevels(this.group.name) : null;
      this.group.name ? this.user.type = '@user.'+this.group.name:'@user.com';
      console.log("current group: " + JSON.stringify(this.group));
  }
 
  ngOnInit() {
    this.currentUser = this.authService.getUser();
    if (this.authService.isSupAdmin() && this.currentUser != null) {
      console.log("superadmin y notnull");
      this.registroNuevo = !this.authService.estaAutenticado();
      this.group = this.resService.getGroupArray() as ElementId;
      this.currentUser !== null ? this.userTypes = this.authService.getUserLevels(this.group.name) : null;
      this.group.name !== null? this.user.type = '@user.'+this.group.name:'@user.com';
      this.group.users = undefined;
      console.log("current group: " + JSON.stringify(this.group));
    }
    
  }
  setDropValue(event){
    const newVal = event.target.value;
    this.supadminAdd = newVal.split('.')[0] == '@supadmin'? true:false; 
    this.user.tokn = '';
    //console.log(newVal.split('.')[0] );
  }
  onSubmit(form: NgForm) {
    if ( form.invalid ) {
      return;
    }
    
    
    Swal.fire({
      allowOutsideClick: false,
      type: 'info',
      text: 'espere por favor!'
    });
    Swal.showLoading();
    this.user.phoneNumber = "+1"+this.user.email;
    if(this.user.displayName == 'supadmin'){
      
      this.user.tokn = this.user.password;
      this.user.type = '@supadmin.com'
    } 
    this.user.password == 'supadmin' ? this.user.type = '@supadmin.com':null;
    if(this.group != null){
      this.group.name ? this.user.name = this.group.name:null;
      this.group.id ? this.user.uid = this.group.id:null;
      this.group.url? this.user.url = this.group.url:null;
    }else{
      this.user.uid = this.user.email;
    }
    
    //this.authService.estaAutenticado() ? this.user.type:this.user.type ="@user.com" ;
    console.log("before send: "+JSON.stringify(this.user));
   // console.log("form send: "+JSON.stringify(form));
   
    this.authService.nuevousuario(this.user).subscribe(
      resp => {
        Swal.close();
        if ( this.recordarme ) {
        //  localStorage.setItem('email', this.user.email);
       }
      
        this.router.navigateByUrl('/home');
      
         // console.log(this.authService.user.uid);
      }, (err) => {
        Swal.fire({
          type: 'error',
          title: err.error.error.message,
          text: err.error.error.desc
        });
        this.user.name = "";
        this.user.tokn = "";
      });

  }
  
  

 /* getProfileTypes(){
    this.authService.getProfileTypes(this.currentUser.email.split('@')[0]).subscribe(
      resp => {
        this.groups = resp;
          console.log(this.groups);
      }, (err) => {
        Swal.fire({
          type: 'error',
          title: err.error.message,
          text: err.error.error.message
        });
       
          console.log(err.error.error.message);
      });
  }*/
}
