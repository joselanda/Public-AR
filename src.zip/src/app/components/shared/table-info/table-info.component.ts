import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Label } from 'ng2-charts';
import { ElementId } from 'src/app/interfaces/element.interface';

@Component({
  selector: 'app-table-info',
  templateUrl: './table-info.component.html',
  styleUrls: ['./table-info.component.css']
})
export class TableInfoComponent implements OnInit, OnChanges {
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    if(this.data!=null){
      this.randomize();
    }
  }
  barChartOptions: ChartOptions = {
    responsive: true,
    // We use these empty structures as placeholders for dynamic theming.
    scales: { xAxes: [{}], yAxes: [{}] },
    plugins: {
      datalabels: {
        anchor: 'end',
        align: 'end',
      }
    }
  };
   barChartLabels: Label[] = ['2006', '2007', '2008'];
   barChartType: ChartType = 'bar';
   barChartLegend = true;

   barChartData: ChartDataSets[] = [
    { data: [65, 59, 80], label: 'Series A' }
  ];
  @Input() data: ElementId[];
  @Input() title: string = 'elements';

  constructor() { }

  ngOnInit() {
    
  }
  public randomize(): void {
    // Only Change 3 values
    this.barChartLabels = [];
    let data = [];
  this.data.forEach(element => {
   // console.log("subcategories:"+JSON.stringify(element));
    this.barChartLabels.push(element.name);
    data.push(parseInt(element.ventas.toString()));
  });
    
   
    this.barChartData[0].data = data;
    this.barChartData[0].label = this.title;
  }
}
