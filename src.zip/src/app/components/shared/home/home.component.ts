import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { window } from 'rxjs/operators';
import { ElementId, Tile } from 'src/app/interfaces/element.interface';
import { AfsService } from 'src/app/services/afs.service';
import { ResourcesService } from 'src/app/services/resources.service';
import { AuthService } from 'src/app/services/auth.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
    user: ElementId;
    currentGroup: ElementId;
    areaBtn = false;
    notas: ElementId[] = [];
    currentElement:ElementId = {};
    editNote = false;
    caller = 'edit';
    isAuth = false;
    tiles: Tile[] = [
        {index: 3, cols: 1, rows: 1, color: 'crimson'},
        {index: 4, cols: 2, rows: 1, color: 'floralwhite'},
        {index: 2, cols: 1, rows: 2, color: 'azure'},
        {index: 1, cols: 3, rows: 1, color: 'burlywood'},
        
      ];
    @ViewChild('itemToSearch') phoneNumber: ElementRef;
  constructor(private afService: AfsService, private resService: ResourcesService, 
              private authService: AuthService) {
    this.version();
  }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem('user'));
    if(this.user !== null){
        this.user.type = this.user.type.split('.')[0];
        this.currentGroup = this.user.groups[0];
        this.currentGroup ? this.getGroupInfo(this.currentGroup):null;
    }
  
    this.isAuth = this.authService.estaAutenticado();
    //console.log("user: "+JSON.stringify(this.user));
  }
  saveNote(){
    
      //console.log("setting current note: "+JSON.stringify(this.currentElement));
      this.resService.setCurrentNote(this.currentElement);
      //this.editNote = true;
  }
  getGroupInfo(group:ElementId){
    this.resService.getGroupFromDB(group).subscribe(res=>{
        this.resService.setGroup(res);
        this.currentGroup = this.resService.getGroupArray() as ElementId;
        //console.log("user: "+JSON.stringify(this.currentGroup));
        this.currentGroup.areas.forEach(area => {
            if(area.name === 'notas'){
                this.areaBtn = true;
                this.getNotas();
            }
        });
      },err=>{return err;});
    
  }
  setCurrentItem(item: ElementId){
   this.currentElement = item;
  }
  getUserNotes(){
    const inputValue = this.phoneNumber.nativeElement.value;
    inputValue != '' ? this.getNotas(`${inputValue}/notas`):null;
  }
  getNotas(url: string = 'publico/general'){
    
    localStorage.setItem("notePath",this.currentGroup.url+'/notas');
    //let query=null;
    //query = this.user.type.split('.')[0] == '@user'?(ref) => ref.where('user', 'array-contains', 'inputValue'):null;
  this.afService.colWithIds$(this.currentGroup.url+'/notas/'+url).subscribe(res=>{
    this.notas = res;
    this.notas.forEach(element => {
        
    });
   });
  }
  switchtEdit(){
      this.editNote = true;
  }
 updateItem(item: ElementId){
     console.log("llega nota para update: "+JSON.stringify(item));
 }
   version() {
    'use strict';

    const module = {
        options: [],
        header: [navigator.platform, navigator.userAgent, navigator.appVersion, navigator.vendor],
        dataos: [
            { name: 'Windows Phone', value: 'Windows Phone', version: 'OS' },
            { name: 'Windows', value: 'Win', version: 'NT' },
            { name: 'iPhone', value: 'iPhone', version: 'OS' },
            { name: 'iPad', value: 'iPad', version: 'OS' },
            { name: 'Kindle', value: 'Silk', version: 'Silk' },
            { name: 'Android', value: 'Android', version: 'Android' },
            { name: 'PlayBook', value: 'PlayBook', version: 'OS' },
            { name: 'BlackBerry', value: 'BlackBerry', version: '/' },
            { name: 'Macintosh', value: 'Mac', version: 'OS X' },
            { name: 'Linux', value: 'Linux', version: 'rv' },
            { name: 'Palm', value: 'Palm', version: 'PalmOS' }
        ],
        databrowser: [
            { name: 'Chrome', value: 'Chrome', version: 'Chrome' },
            { name: 'Firefox', value: 'Firefox', version: 'Firefox' },
            { name: 'Safari', value: 'Safari', version: 'Version' },
            { name: 'Internet Explorer', value: 'MSIE', version: 'MSIE' },
            { name: 'Opera', value: 'Opera', version: 'Opera' },
            { name: 'BlackBerry', value: 'CLDC', version: 'CLDC' },
            { name: 'Mozilla', value: 'Mozilla', version: 'Mozilla' }
        ],
        init: function () {
            const agent = this.header.join(' '),
                os = this.matchItem(agent, this.dataos),
                browser = this.matchItem(agent, this.databrowser);

            return { os: os, browser: browser };
        },
        matchItem: function (string, data) {
            let i = 0,
                j = 0,
                html = '',
                regex,
                regexv,
                match,
                matches,
                version;

            for (i = 0; i < data.length; i += 1) {
                regex = new RegExp(data[i].value, 'i');
                match = regex.test(string);
                if (match) {
                    regexv = new RegExp(data[i].version + '[- /:;]([\\d._]+)', 'i');
                    matches = string.match(regexv);
                    version = '';
                    if (matches) { if (matches[1]) { matches = matches[1]; } }
                    if (matches) {
                        matches = matches.split(/[._]+/);
                        for (j = 0; j < matches.length; j += 1) {
                            if (j === 0) {
                                version += matches[j] + '.';
                            } else {
                                version += matches[j];
                            }
                        }
                    } else {
                        version = '0';
                    }
                    return {
                        name: data[i].name,
                        version: parseFloat(version)
                    };
                }
            }
            return { name: 'unknown', version: 0 };
        }
    };

    const e = module.init();
       let debug = '';

    debug += 'os.name = ' + e.os.name + '<br/>';
    debug += 'os.version = ' + e.os.version + '<br/>';
    debug += 'browser.name = ' + e.browser.name + '<br/>';
    debug += 'browser.version = ' + e.browser.version + '<br/>';

    debug += '<br/>';
    debug += 'navigator.userAgent = ' + navigator.userAgent + '<br/>';
    debug += 'navigator.appVersion = ' + navigator.appVersion + '<br/>';
    debug += 'navigator.platform = ' + navigator.platform + '<br/>';
    debug += 'navigator.vendor = ' + navigator.vendor + '<br/>';
    //console.log(debug);
}


// document.getElementById('log').innerHTML = debug;
}
