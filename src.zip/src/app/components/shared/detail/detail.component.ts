import { Component, OnInit, Input, Output, EventEmitter, OnChanges, AfterContentInit} from '@angular/core';
import { AngularFirestore, AngularFirestoreCollection } from '@angular/fire/firestore';
import { Observable } from 'rxjs';
import Swal from 'sweetalert2';
import { FirestoreService } from 'src/app/services/firestore.service';
import { ElementId, Elemento } from 'src/app/interfaces/element.interface';
import { AfsService } from 'src/app/services/afs.service';
import { ResourcesService } from 'src/app/services/resources.service';


@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.css']
})
export class DetailComponent implements OnInit, OnChanges, AfterContentInit {
  ngAfterContentInit(): void {
    
    
  }
  
  @Input() reset: boolean;
  @Input() caller: string;
  @Input() subCaller: string;
  @Input() items: ElementId[];
  @Input() group: ElementId;
  @Input() folderName: string;
  @Output() addItemNote: EventEmitter<ElementId>;
  @Output() addItem: EventEmitter<ElementId>;
  @Output() subItem: EventEmitter<ElementId>;
  @Output() categoryItem: EventEmitter<ElementId>;
  Swal = require('sweetalert2');
  currentItems :ElementId[];
  currentItem: ElementId;
  currentCategory: ElementId;
  currentElement: ElementId = {name:"hola",description:"prueba"};
  currentSubcategory: ElementId = {name:"hola",description:"prueba"};
  modalCaller = 'detailComponent';
  templateElement: ElementId;
  templateElementFull: ElementId = {name:null,description:null, status:true};
  newElement: boolean =false;
  isSubCaller:boolean = false;
  selectedItem: string='';
  currentCaller: string='';
  constructor(private afService: AfsService, private angularfs: AngularFirestore,
              private resService: ResourcesService) {
    
    this.addItemNote = new EventEmitter<ElementId>();
    this.addItem = new EventEmitter<ElementId>();
    this.subItem = new EventEmitter<ElementId>();
    this.categoryItem = new EventEmitter<ElementId>();
   }

  ngOnInit() {
    this.currentItems = this.items;
    if(this.currentItems !== undefined){
      this.currentItem = this.currentItem[0];
    }
    this.setDefaultTemplate();
    this.setCaller('Categoria');
    this.isSubCaller = this.subCaller == "notas"?true:false;
    
  }
  setElementTemplate(){
  this.templateElement = {
    name:null,
    description:null,
    images: null,
    status: true,
    stock: null,
    measure:null,
    ventas: 0,
    docs:null,
    comments:null,
    precioVta:null,
    precioCompra:null,
    hastags:null,
    imei: null
  };
  //this.templateElement = {} as ElementId;
  //this.templateElement.displayName = null;
}
setDefaultTemplate(){
  this.templateElementFull = {
    name:null,
    description:null,
    status: true,

   
  };
}

  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
   
    this.currentItems = this.items;
    if(this.currentItems !== undefined && this.caller != this.currentCaller){
    this.resetTabs();
    }
   //console.log("ONCHANGES detail group: "+JSON.stringify(this.group));
    this.currentCaller = this.caller;
  }
  addItemToNote(item: ElementId){
    //console.log('sending Update product from detail component: '+JSON.stringify(item));
    this.addItemNote.emit(item);
  }
  resetTabs(){
    const sub = (<HTMLInputElement> document.getElementById('subCatBtn'));
    
    const ele = (<HTMLInputElement> document.getElementById('elemBtn'));
   
    if(sub !=null && ele != null){
      sub.disabled = true;
      ele.disabled = true;
    
      document.getElementById('catBtn').click();
    }
    
  }
  setItem(item: ElementId) {
    //console.log("setting currentItem: "+JSON.stringify(item));
    this.currentItem = item;
    this.selectedItem = this.currentItem.name;
    //this.addItem.emit(item);
    (<HTMLInputElement>document.getElementById('subCatBtn')).disabled = false;
    document.getElementById('subCatBtn').click();
  }
  setSubCategories(subcategory: ElementId){
    //console.log("seteando subcategoria: "+JSON.stringify(subcategory));
    this.currentCategory = subcategory;
    (<HTMLInputElement> document.getElementById("elemBtn")).disabled = false;
    this.getElements(this.currentCategory.url+'/'+this.currentCategory.name);
    (<HTMLInputElement> document.getElementById("elemBtn")).click();
  }
  setCurrentElement(element: ElementId){
    this.newElement = false;
   //console.log("SEtting element: "+JSON.stringify(element));
  this.currentElement = element;
    //(<HTMLInputElement> document.getElementById("exampleModal")).click();

  }
  getCategories(item: ElementId){
    //console.log("setting currentItem: "+JSON.stringify(item));
    this.currentItem = item;
   this.selectedItem = this.currentItem.name;
   //this.addItem.emit(item);
   (<HTMLInputElement> document.getElementById('subCatBtn')).disabled = false;
   document.getElementById('subCatBtn').click();
  }
  getSubCategories(subcategory:ElementId){
   //console.log("seteando subcategoria: "+JSON.stringify(subcategory));
   this.currentCategory = subcategory;
   /*this.categoryItem.emit(category);
   console.log("emitiendo elemento con categoria: "+JSON.stringify(this.currentItem)+" y categoria "+JSON.stringify(subcategory));
    //this.subItem.emit(this.currentItem);*/
    (<HTMLInputElement> document.getElementById("elemBtn")).disabled = false;
  
    (<HTMLInputElement> document.getElementById("elemBtn")).click();

  }
 
  updateItem(element: ElementId){
    (<HTMLInputElement> document.getElementById("dismissModal")).click();
    //console.log("Editar Elemento: "+JSON.stringify(element));
  }
  insertItem(element: ElementId){
   // console.log("llega forma: "+JSON.stringify(element)+"modalcaller: "+this.modalCaller);
    Swal.showLoading();
    (<HTMLInputElement>document.getElementById("dismissModal")).click();
    let url = '';
    element.name = element.name.toLowerCase();
    switch (this.modalCaller) {
      case 'Categoria':
        //setItemconsole.log("Insertar categoria: " + 'groups/' + this.group.id + "/groups/" + this.group.name + "/" + this.folderName);
        url ='groups/' + this.group.id + '/groups/' + this.group.name + '/' + this.folderName;
        element.url = url;
       
        this.afService.col(url).add(element).then(res => {

          Swal.close();
          //console.log("inserting firestore element: " +JSON.stringify(res));
        }).catch(err => {
          Swal.close();
          //console.log("error inserting element: " +JSON.stringify(err));
        });//Se forma la url porque no trae el parametro URL

       
        
        break;
      case 'Subcategoria':
        element.status = false;
        url = 'groups/' + this.group.id + '/groups/' + this.group.name + '/' + this.folderName + '/' + this.currentItem.id;
        element.url = url;
      // console.log("Insertar subcategoria: " +url+' element collection: '+element.name+' elemento: '+JSON.stringify(element));
        this.afService.doc(url).collection(element.name).add(element).then(res => {
          
          Swal.close();
        }).catch(err => {
          Swal.close();
          //this.getSubCategories(this.currentItem);
          console.log("error inserting element: " +JSON.stringify(err));
        });
        this.currentItem.categories = this.currentItem.categories == undefined ? []:this.currentItem.categories;
        this.currentItem.categories.push({ name: element.name, url: element.url });
        this.afService.doc(url).set(
          { categories: this.currentItem.categories },
          { merge: true }
        )

        break;
      case 'Elemento':
        //console.log("Insertar elemento: " +'groups/'+this.group.id+"/groups/"+this.group.name+"/"+
        //this.folderName+"/"+this.currentItem.id+"/"+this.currentSubcategory.id+"/");
        url = 'groups/' + this.group.id + '/groups/' + this.group.name + '/' + this.folderName + '/'
          + this.currentItem.id;
          let urlItem = url;
          url+= '/' + this.currentCategory.name;
         // console.log("Insertar elemento: " +JSON.stringify(element)+" en "+url);
          element.url = url;

          element.hastags = element.name.split(" ");
          element.group = this.group.name;
         // if(element.id == null){
            element.id = element.name.replace(/ /g, '');
            let date = this.afService.getTimeStamp();
           // console.log("Insert elemento: " +JSON.stringify(date)+" en "+url);
            this.afService.set('products/'+element.id,element).then(res => {
            // console.log("documento insertado: " +JSON.stringify(res));
             this.afService.set(url+'/'+element.id,element);
             Swal.close();
           }).catch(err => {
             Swal.close();
             //this.getSubCategories(this.currentCategory);
             //console.log("error inserting element: " +JSON.stringify(err));
           });
        /*  }
         else{
          console.log("Update elemento: " +JSON.stringify(element)+" en "+url);
           this.afService.doc(url+"/"+element.id).update(element).then(res=>{
             this.afService.doc('products/'+element.id).update(element);
              Swal.close();
            }).catch(()=>Swal.close());
      }*/
       // this.getElements(url);
        this.setCaller('Elemento');
        
        break;
        case 'edit':
          url = element.url;
         // console.log("Update elemento: " +JSON.stringify(element)+" en "+url);
          this.afService.doc(url+"/"+element.id).update(element).then(res=>{
            console.log("ok products in folder:"+JSON.stringify(res));
            Swal.close();
            
           }).catch(err=>{
            Swal.close();
            console.log("not ok products in folder:"+JSON.stringify(err));
           });
           //this.setCaller('Elemento');
           this.afService.doc('products/'+element.id).update(element).then(res=>{
            console.log("ok products:"+JSON.stringify(res));
            Swal.close();
          }).catch(err=>{
            console.log("not ok products:"+JSON.stringify(err));
            Swal.close();
          });
          this.setCaller('Elemento');
        break;

      default:
        Swal.close();
        break;
    }
    
    /**/
    //console.log("Insertar Elemento: " +'groups/'+this.group.id+"/groups/"+this.group.name+"/"+this.folderName);
  }
  getElements(urlItem:string){
    //console.log("getting elements: "+JSON.stringify( urlItem));
    const query = (ref) => ref.where('status', "==", true);
    this.afService.colWithIds$(urlItem,query).subscribe(res=>{
      this.currentItem.categories.find(cat => cat ==this.currentCategory).elements = this.currentItem.categories.find(cat => cat ==this.currentCategory).elements== undefined ? []:this.currentItem.categories.find(cat => cat ==this.currentCategory).elements;
      this.currentItem.categories.find(cat => cat ==this.currentCategory).elements = res;
      //console.log("categorie: "+JSON.stringify( this.currentItem.categories));
    });
  }
 

  setCaller(caller: string){
    //console.log("setCaller: "+caller);
    caller =='Elemento'? this.setElementTemplate():this.setDefaultTemplate();
 
    this.modalCaller = caller;
  }

  editElement(subcategorie: ElementId){
    //this.setCurrentElement(subcategorie);
    this.newElement = true;
    //this.setDefaultTemplate();*/
    this.templateElement = subcategorie;
    this.modalCaller = 'edit';
  }
//#region setting templates by button agregar function
  addCategorie(){
    this.templateElement = this.resService.getGroupArray('templateCat') as ElementId;
   // console.log("Current this.templateElement: "+JSON.stringify(this.templateElement));
    this.newElement = true;
  }
  addSubCategorie(){
    this.templateElement = this.resService.getGroupArray('templateSubCat') as ElementId;
  
    this.newElement = true;
  }
  setNewElement(){
    this.templateElement = this.resService.getGroupArray('templateElem') as ElementId;
    //this.setElementTemplate();
    this.newElement = true;
    this.setCaller('Elemento');
  }
  //#endregion
  saveRoute(){
    
    console.log("Current subcategory: "+this.currentCategory.url+"/"+this.currentCategory.name);
  }
}
