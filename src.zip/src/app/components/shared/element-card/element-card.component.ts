import { Component, OnInit, Input, Output, EventEmitter, OnChanges } from '@angular/core';
import { ElementId } from 'src/app/interfaces/element.interface';
import { AuthService } from 'src/app/services/auth.service';
import { FormGroup, FormBuilder, Validators, FormArray } from '@angular/forms';

@Component({
  selector: 'app-element-card',
  templateUrl: './element-card.component.html',
  styleUrls: ['./element-card.component.css']
})
export class ElementCardComponent implements OnInit, OnChanges {
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    //console.log('onchanges app-element: ', this.caller+"issubcaller: "+this.isSubCaller+" element: "+JSON.stringify(this.item));
    this.item.stock !== undefined ? this.crearFormulario():null;
    if(this.item.images !== undefined){
      this.images = [];
      let number: number = parseInt(Object.keys(this.item.images).length.toString()) ;
      console.log("url "+number);
      for (let index = 0; index < number; index++) {
        //console.log("times: "+ this.item.images[index].url);
        this.images.push(this.item.images[index].url);
      }
    }
    
   
    
   
  }

  @Input() caller: string;
  @Input() isSubCaller: boolean;
  @Input() item: ElementId;
  @Output() deleteItem: EventEmitter<ElementId>;
  @Output() detailItem: EventEmitter<ElementId>;
  @Output() addItem: EventEmitter<ElementId>;
  @Output() insertItem: EventEmitter<ElementId>;
  @Output() itemId: EventEmitter<ElementId>;
  @Output() removeItem: EventEmitter<ElementId>;
  currentUser: ElementId = null;
  subTotal: number = 0;
  cant = 1;
  forma: FormGroup;
  images:string[]=[];
  constructor(private fb: FormBuilder, private groupSvc: AuthService) {
    this.deleteItem = new EventEmitter();
    this.detailItem = new EventEmitter();
    this.addItem = new EventEmitter();
    this.itemId = new EventEmitter();
    this.removeItem = new EventEmitter();
    this.insertItem = new EventEmitter();
   }

  ngOnInit() {
    //console.log('init app-element: ', this.caller+" element: "+JSON.stringify(this.item));
  }
  crearFormulario() {
    this.forma = this.fb.group({
      'cantidad':this.fb.control(this.cant,[Validators.required,Validators.min(0),Validators.max(this.item.stock)]),
      'precioVta':this.fb.control(this.item.precioVta,[Validators.required,Validators.min(0)])
     });
     this.forma.get('cantidad').valueChanges.subscribe( value =>{
       this.subTotal = parseInt(this.forma.get('precioVta').value) * value;
      console.log("subtotal cant: "+this.subTotal);
     } );
     this.forma.get('precioVta').valueChanges.subscribe( value =>{
      this.subTotal = parseInt(this.forma.get('cantidad').value) * value;
     console.log("subtotal pvta: "+this.subTotal);
    } );
     
     this.subTotal = this.item.precioVta;
    //this.forma.setControl();
    //ading default fields to form name and description
    /*this.item.name !== undefined ? this.addTextInput('name',this.item.name != null ?this.item.name : ""):null;
    this.item.description !== undefined? this.addTextInput('description',
    this.item.description != null ?this.item.description : ""):null;
    this.item.status !== undefined ? this.agregarStatus(): null;*/
  }

  detail() {
    this.detailItem.emit(this.item);
  }
  remove(item: ElementId) {
    if (this.item) {
      for (let i = 0; i < this.item.elements.length; i++) {
        if (this.item.elements[i] === item) {
          // console.log('currentPlayList.element to delete: ', this.item.elements[i]);
          this.item.elements.splice(i, 1);
        }
      }
    }
    this.removeItem.emit(this.item);
  }

  get ventasNotValid() {
    return this.forma.get('cantidad').invalid 
  }
  calcularSubtotal(){
    if(this.forma.get('cantidad').value == 0){
      (<HTMLInputElement> document.getElementById("errForm")).innerHTML = 'Algún dato o cantidad es incorrecta.';
      return;
    }
    console.log( this.forma );
    //this.element.password = "password";
    if ( this.forma.invalid ) {

      return Object.values( this.forma.controls ).forEach( control => {
        
        if ( control instanceof FormGroup ) {
          Object.values( control.controls ).forEach( control => control.markAsTouched() );
        } else {
          control.markAsTouched();
        }
        
        
      });
     
    }else{
      this.item.cantidad = this.forma.get('cantidad').value;
      //this.item.subtotal = this.item.precioVta;
      this.item.subtotal = parseInt(this.subTotal.toString());
      console.log("subtotal item:"+this.item.subtotal);
      this.insertItem.emit(this.item);
      this.forma.reset();
      (<HTMLInputElement> document.getElementById("dismissModal")).click();

    }
    
   // let cantidad = (<HTMLInputElement> document.getElementById("agregarBtn")).value;
    //cantidad += parseInt(cantidad);
  }
  delete() {
    this.deleteItem.emit(this.item);
  }
  add() {
    // console.log('emitiendo elemento: ', this.item);
    this.addItem.emit(this.item);
  }

  sendItemId() {
    this.itemId.emit(this.item);
  }

  callerLists() {
    return this.caller === 'lists' ? true : false;
  }
  callerTvs() {
    return this.caller === 'tvs' ? true : false;
  }
  callerInsideTvs() {
    return this.caller === 'tvElement' ? true : false;
  }
  callerElement() {
    return this.caller === 'element' ? true : false;
  }
  callerListElement() {
    return this.caller === 'listElement' ? true : false;
  }
  callerListUser() {
    return this.caller === 'users' ? true : false;
  }
  callerGroupList() {
    return this.caller === 'groupsList' ? true : false;
  }
  callerHome() {
    return this.caller === 'home' ? true : false;
  }
  isSupAdmin() {
    return this.groupSvc.isSupAdmin();
  }

}
