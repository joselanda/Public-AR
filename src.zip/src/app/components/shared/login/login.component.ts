import { Component, OnInit, OnDestroy } from '@angular/core';
import { Elemento } from 'src/app/interfaces/element.interface';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../../services/auth.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';
import { AfsService } from 'src/app/services/afs.service';
import { Observable } from 'rxjs';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { ElementId } from '../../../interfaces/element.interface'
import 'firebase/auth';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, OnDestroy {
user: ElementId = {} as ElementId;
Swal = require('sweetalert2');
firebase = require('firebase');
firebaseui = require('firebaseui');
recordarme = false;

ref: AngularFirestoreCollection<ElementId>;
elements: Observable<ElementId[]>;
  constructor(private authLogin: AuthService,
              private router: Router, private afserv: AfsService, private afs: AngularFirestore) { }
  ngOnDestroy(): void {
   // localStorage.setItem('user',null);
  }

  ngOnInit() {
    if (localStorage.getItem('email')) {
      this.user.email = localStorage.getItem('email');
      this.recordarme = true;
    }
  }
  login(form: NgForm) {
    if ( !form.valid ) {
     return;
    }
    let temppass = this.user.password;
    let tempUser: ElementId = this.user;
    
    this.afserv.doc$('users/'+this.user.email).subscribe(res => {
      
      if (typeof res !== "undefined") {
        //console.log("res"+res);
        this.user = res as ElementId;

        if(this.user){
          // console.log("elementid"+this.user);
          localStorage.setItem('user', JSON.stringify(this.user));
           this.user.password = temppass;
          // console.log(this.user.type);
           this.user.email = this.user.email;
         Swal.fire({
           allowOutsideClick: false,
           type: 'info',
           text: 'espere por favor!'
         });
         Swal.showLoading();
         this.authLogin.login( this.user ).subscribe(
          resp => {
            Swal.close();
            this.router.navigateByUrl('/home');
            //localStorage.setItem('token', this.user.email);
            this.user.password = "";
            
            localStorage.setItem("user", JSON.stringify(this.user));
           //console.log("saved user"+localStorage.getItem("user"));
            if ( this.recordarme ) {
              // localStorage.setItem('email', this.user.email);
            }
          }, (err) => {
           Swal.fire({
             type: 'error',
             title: 'Error al autenticar',
             text: err.error.error.message
           });
           this.user.email = this.user.email.substring(0,10);
           localStorage.removeItem('token');
           localStorage.removeItem('email');
            // console.log(err.error.error.message);
          }
         );
       }else{
         Swal.fire({
           type: 'error',
           title: 'Error al autenticar',
           text: "No estas dado de alta en el serv de Auth"
         });
       }

      }else
      {
        Swal.fire({
          type: 'error',
          title: 'Error al autenticar',
          text: "No estas dado de alta en BD"
        });
      
      }
      
      
     
     
    });
   
    //console.log(form);
  }
}
