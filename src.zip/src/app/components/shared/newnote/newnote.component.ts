import { Component, OnInit, OnChanges } from '@angular/core';
import { ElementId } from 'src/app/interfaces/element.interface';
import { AfsService } from 'src/app/services/afs.service';
import { Router } from '@angular/router';
import { ElementsService } from 'src/app/services/elements.service';
import Swal from 'sweetalert2';
import { ResourcesService } from 'src/app/services/resources.service';

@Component({
  selector: 'app-newnote',
  templateUrl: './newnote.component.html',
  styleUrls: ['./newnote.component.css']
})
export class NewnoteComponent implements OnInit, OnChanges {

  defaultNote: ElementId;
  caller: string = 'Nueva Nota';
  area: string = 'notas';
  notePath = '';
  constructor(private afService: AfsService, private router: Router,
    private elementService: ElementsService, private resService: ResourcesService) {
    
  }
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {}
   

  ngOnInit() {
    //console.log("noytepath: " + localStorage.getItem("notePath"));
    this.notePath = localStorage.getItem("notePath");
    this.resService.getCurrentNote() != null ? this.defaultNote = this.resService.getCurrentNote():this.setDefaultNote();
    //console.log("this.currentNote: "+JSON.stringify(this.defaultNote));
  
  }
  setDefaultNote(){
    this.defaultNote = {
      description: "Público en General",
      images: [],
      comments: [],
      products: [],
      users: [],
      status: true
    }
  }
  addItemToNote(item: ElementId) {
    item.url = this.notePath;
    item.status = true;
    

    console.log("llegar item form" + JSON.stringify(item));
    Swal.showLoading();
    //this.defaultNote.elements.push(item);
   /* this.afService.col(this.notePath).add(item).catch(res => {
      Swal.close();
      console.log("successfully inserted" + JSON.stringify(res));
      this.router.navigateByUrl('/home');
    }).then(err => {
      Swal.close();
      console.log("failure" + JSON.stringify(err));
      this.router.navigateByUrl('/home');
    });*/
    console.log("item: "+JSON.stringify(item));
      this.elementService.insertNote(item).subscribe(res => {
        //console.log("respuesta del servicio: " + JSON.stringify(res));
        Swal.close();
        this.router.navigateByUrl('/home');
      },error=>{
        console.log("Error al insertar");
        Swal.close();
        Swal.fire({
          type: 'error',
          title: 'Error al insertar Nota',
          text: error.error.message
        });
      });
   
   

  }
}
