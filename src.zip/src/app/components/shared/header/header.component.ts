import { Component, OnInit, OnChanges, OnDestroy } from '@angular/core';
import { NavbarService } from '../../../services/navbar.service';
import { AuthService } from '../../../services/auth.service';
import { Router } from '@angular/router';
import { ElementId } from '../../../interfaces/element.interface';
import { UsersService } from 'src/app/services/users.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit, OnChanges, OnDestroy {
logged = false;
esUsuario = false;
esAdministrador = false;
esSuperadministrador = false;
usuario = "";
currentUser: ElementId = null;
  constructor(public nav: NavbarService,
              public authService: AuthService,
              private router: Router) {
                
              }
  ngOnDestroy(): void {
    console.log("ondestroy user Header: "+JSON.stringify(this.currentUser));
  }
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
 
    console.log("onchanges user Header: "+JSON.stringify(this.currentUser));
  }

  ngOnInit() {
    this.logged = this.authService.estaAutenticado();
    if(this.logged){
      this.currentUser = this.authService.getUser();
      /*this.esAdministrador = this.authService.isSupAdmin();
    this.esSuperadministrador = this.authService.isAdmin();
    this.esUsuario = this.authService.isUser();
    console.log("this.logged: "+this.logged);*/
    
  //console.log("oninit user Header: "+JSON.stringify(this.currentUser));
    }
    
  }

  getDisplayName(): string{
    return this.authService.getdisplayName();
  }
 get islogged(){
   return this.logged = this.authService.estaAutenticado();
 }
 get isAdmin(){
  return this.authService.isAdmin();
 }
  hideShow(){
    this.nav.hide();
  }
  
  get isSupAdmin(): boolean {
  return this.authService.isSupAdmin();
  }

  /*isAdmin():boolean{
    return this.authService.isAdmin();
  }*/

  isUser(){
    return this.authService.isUser();
  }
  logOut() {
    this.currentUser = null;
    this.authService.logout();
    
    
    this.router.navigateByUrl('/login');
  }
}
