import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

import { AfsService } from 'src/app/services/afs.service';
import { ElementId, Elemento } from 'src/app/interfaces/element.interface';
import { ResourcesService } from 'src/app/services/resources.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  @Input() caller: string;
  @Input() type: string;
  @Output() updateElement: EventEmitter<ElementId>;
  elementCaller: string = 'notas';
  groups: ElementId[];
  currentGroup: ElementId;
  products: ElementId[];
  elements: ElementId[];
  currentProduct : ElementId;
  currentService : ElementId;
  currentElement : ElementId;
  services: ElementId[];
  notes: ElementId[];
  categorias: ElementId[];
  subcategoria: ElementId[];
  user: ElementId;
  currentCategory: ElementId;
  reset: boolean = false;
  folderName: string;
  simpleGroup:ElementId={};
  constructor(private afService: AfsService, private resService: ResourcesService) {
    this.updateElement = new EventEmitter<ElementId>();
   }

  ngOnInit() {
   // console.log("user"+localStorage.getItem('user'));
    this.user = JSON.parse(localStorage.getItem('user'));
    this.user.type = this.user.type.split('.')[0];
    //this.type === 'newNote' ? this.currentGroup = this.resService.getGroupArray() as ElementId : 
    this.currentGroup = this.user.groups[0];
    this.currentGroup ? this.getGroupInfo(this.currentGroup):null;
    //console.log("ngInit dasboard"+JSON.stringify(this.currentGroup));
   
  }

  
   getGroupInfo(group:ElementId){
    this.resService.getGroupFromDB(group).subscribe(res=>{
        this.resService.setGroup(res);
        this.currentGroup = this.resService.getGroupArray() as ElementId;
        this.simpleGroup = this.currentGroup;
        this.simpleGroup.users = undefined;
        //console.log("user: "+JSON.stringify(this.simpleGroup));
        
      },err=>{return err;});;
    
  }

   compare(a: ElementId, b:ElementId) {
     //comparing the elements by order number
    const first = a.orden;
    const second = b.orden;
  
    let comparison = 0;
    if (first > second) {
      comparison = 1;
    } else if (first < second) {
      comparison = -1;
    }
    return comparison;
  }
  getFolder(nameFolder: string){
    //console.log("getFolder dashboard and group: "+JSON.stringify(this.resService.getGroupArray()));
    this.elementCaller = nameFolder;
    this.getSubcollection(this.elementCaller);
   this.folderName = nameFolder;
    //this.folderName = this.getFolderName();
    console.log("getFolder item dashboard:"+ nameFolder);
  }
 /* getProducts(){
    //console.log("getProducts dashboard:");
    this.elementCaller = 'productos';
    this.getSubcollection('products');
    this.folderName = this.getFolderName();
    
  }
  getServices(){
    this.elementCaller = 'servicios';
    this.getSubcollection('services');
    this.folderName = this.getFolderName();
  }
  getNotes(){
    this.elementCaller = 'notas';
    this.getSubcollection('notes');
    this.folderName = this.getFolderName();
    
  }*/

  getSubcollection(element: string){
    this.reset = true;
   // console.log(' dashboard getSubcollections: '+JSON.stringify(element));
    this.afService.colWithIds$<ElementId>('groups/'+this.currentGroup.id+"/groups/"+this.currentGroup.name+"/"+element+"").subscribe(res=>{
      //this.services = res;
      this.elements = res;
     
    })
    //console.log("elementos: "+JSON.stringify(this.elements));
    //this.reset = false;
  }
//#region GETTING CATEGORIES
  getProductCategorie(product: ElementId){
    this.currentElement = product;
    this.currentElement.categories = [];
  
    console.log(' dashboard: '+JSON.stringify(product));
  this.getCategories(product.id,this.folderName);
  
  }
  addItemToNote(item: ElementId){
    console.log("emitiendo desde dashboard: "+JSON.stringify(item));
    this.updateElement.emit(item);
  }

  //#endregion

 //#region GETTING SUBCATEGORIES
  
  getProductSubCategorie(producto: ElementId){
    this.currentElement = producto;
    console.log("dashboard subcategoria producto que llega: "+JSON.stringify(producto));
  
  this.getSubCategories(producto.id,this.folderName);
  }

//#endregion
  getCategories(elementId:string,type:string){
    
    console.log("url a enviar: "+'groups/'+this.currentGroup.id+'/groups/'+this.currentGroup.name+'/'+type+'/'+elementId);
    this.afService.getSubcollection('groups/'+this.currentGroup.id+'/groups/'+this.currentGroup.name+'/'+type+'/'+elementId).subscribe(resp=>{
      //console.log(JSON.stringify(resp));
      
      resp.forEach(element => {
        let elementId: ElementId = {
          id: element,
         name : element
        };
        this.currentElement.categories.push(elementId);
 
      });
    });
  }

  getSubCategories(subcategory:string,type: string){
    //console.log("recibiendo subcategoria: "+subcategory);
    let elementId:string;
    elementId = this.currentElement.id;
    const query = (ref) => ref.where('status', "==", true);
   console.log("GETTING subcategory"+'groups/'+this.currentGroup.id+'/groups/'+this.currentGroup.name+'/'+type+'/'+elementId+'/'+this.currentCategory.name);
    this.afService.colWithIds$<ElementId>('groups/'+this.currentGroup.id+'/groups/'+this.currentGroup.name+'/'+type+'/'+elementId+'/'+this.currentCategory.name,query).subscribe(res=>{
      this.currentElement.subcategories = res;
    })
  }

  newElement(element: ElementId){
   console.log("elemento a insertar: "+JSON.stringify(element));
  }

  setCurrentCategory(category: ElementId){
    //console.log("SETTING current CATEGORY: "+JSON.stringify(category));
   this.currentCategory = category;
  }

 /* getFolderName(){
    switch (this.elementCaller) {
      case 'productos':
       return 'products';
        case 'servicios':
        return  'services';
      default:
       return 'notes';
        
    }
  }*/

}
