import { Component, OnInit } from '@angular/core';
import { UsersService } from '../../../services/users.service';
import { Router } from '@angular/router';
import { Elemento } from '../../../interfaces/element.interface';
import { Observable } from 'rxjs';
import { ElementId } from 'src/app/interfaces/element.interface';
import Swal from 'sweetalert2';
import { AfsService } from 'src/app/services/afs.service';


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
  userSelected =false;
user: ElementId;
userTemplate:Elemento= {
  displayName : "",
  status: true
};
currentUser : ElementId;
users:ElementId[] = [];
//@Output() addItem: EventEmitter<ElementId>;

public caller = 'users';
  constructor(private userService: UsersService,
    private router: Router, private afserv: AfsService) { 
      
    }

  ngOnInit() {
    this.user = JSON.parse(localStorage.getItem("user"));
      this.getUsers('enabled');
  }
  setUsersTemplate(){
    
  }
  setCurrentItem(item: ElementId) {
    console.log('CURRENTUSEREL: ', item);
    this.userTemplate.displayName = item.displayName;
    this.currentUser = item;
    this.currentUser.images = [];
    this.userSelected = true;
    this.currentUser.password = "";
    //console.log('CURRENTUSEREL: ', item);
  }
  getUsers(enabled:string = "enabled"){
    const query = (ref) => ref.where('status', "==", enabled =='enabled' ?true:false);
  /*// let type: string = this.user.type;
    this.userService.getUsers(enabled, type).subscribe(resp =>{
      resp.forEach(element => {
        element.url = element.photoURL != null ? element.photoURL : "https://firebasestorage.googleapis.com/v0/b/publicastv-a67df.appspot.com/o/file%20%2Fuser.jpg?alt=media&token=93ab9e34-5701-458f-8cc8-05ec4c1715cb",
        element.id = element.uid;
        element.type = element.email.substring(11,element.email.length);
        element.email = element.email.substring(0,10);
        element.phoneNumber = element.email;
        //console.log("ELement type: foreach "+element.type);
        element.displayName != null ? element.displayName : element.email;
        //this.users.push(element);
      });
      this.users = resp;
     // console.log(this.users);
    },(error) => {
     // console.log(error.error.error.message);
    });*/
    //console.log("respuesta usuarios: "+JSON.stringify(this.user));
    const email = this.user.email.split('@')[0];
    if(this.user.owner){
      this.afserv.col$<ElementId>('groups/'+email+"/users",query).subscribe(res=>{
        this.users = [];
        res.forEach(element=> {
          if(element.email != this.user.email){
            element.url = element.photoURL != null ? element.photoURL : "https://firebasestorage.googleapis.com/v0/b/publicastv-a67df.appspot.com/o/file%20%2Fuser.jpg?alt=media&token=93ab9e34-5701-458f-8cc8-05ec4c1715cb",
            element.id = element.uid;
            element.type = element.email.substring(11,element.email.length);
            element.email = element.email.substring(0,10);
            element.phoneNumber = element.email;
            //console.log("ELement type: foreach "+element.type);
            element.displayName != null ? element.displayName : element.email;
          this.users.push(element);
          }
         
         
        });
        //this.users = res;
        
        // console.log("respuesta usuarios: "+JSON.stringify(res));
      });
    }else{

    }

   
  }
  reload(){
    console.log("on reload");
    this.ngOnInit();
  }
  deleteUser(item: ElementId){
    let nuevoItem = item;
    //console.log("ITEMTYPE: "+item.type);
    Swal.fire({
      allowOutsideClick: false,
      type: 'info',
      text: 'Eliminando Registro!'
    });
    Swal.showLoading();
    if(document.getElementById('closeModal') != null)
    document.getElementById('closeModal').click();
    else item.disabled = true;
    nuevoItem.id = item.id;
    nuevoItem.email = item.email;
   // console.log("eliminar id: "+nuevoItem.id+" email: "+nuevoItem.email);
    
   this.afserv.doc('groups/'+this.user.email.split('@')[0]+'/users/'+item.email.split('@')[0]).set({
     status: false
   },{merge: true}).then(res=>{
      Swal.close();
   }).catch(error=>{
    Swal.close();
   });
    /*this.userService.deleteUser(nuevoItem).subscribe( resp => {
    
     Swal.close();
     this.getUsers();
     //this.ngOnInit();
   }, (err) => {
    Swal.close();
    Swal.fire({
      type: 'error',
      title: 'Error al registrar',
      //text: "El usuario "+this.user.email+" ya esta registrado"
      text: err.error.error.message
    });
       console.log(err.error.error.message);
   });*/

   
  }

  upDateUser(item: ElementId) {
    let nuevoItem = item;
    console.log("ITEMT Llega: "+JSON.stringify(nuevoItem));
    /*Swal.fire({
      allowOutsideClick: false,
      type: 'info',
      text: 'Actualizando Registro!'
    });
    Swal.showLoading();*/
    if(document.getElementById('closeModal') != null)
    document.getElementById('closeModal').click();
    else item.disabled = true;
    nuevoItem.phoneNumber = item.email.length < 11 ?"+1"+item.email:item.email;
    nuevoItem.email = item.email.length < 11 ? item.email+"@"+item.type:item.email;
    nuevoItem.password  != "" ? item.password: "no";
    console.log("ITEMTNuevo: "+JSON.stringify(nuevoItem));
    //this.afserv.doc$('/groups/')
   /* this.userService.updateUser(nuevoItem).subscribe( resp => {
    
     Swal.close();
     this.getUsers();
     //this.ngOnInit();
   }, (err) => {
    Swal.close();
    Swal.fire({
      type: 'error',
      title: 'Error al registrar',
      //text: "El usuario "+this.user.email+" ya esta registrado"
      text: err.error.error.message
    });
       console.log(err.error.error.message);
   });*/
 
   }
 /* delete(item: ElementId) {
   item.disabled = true;
   item.password = "no";
   this.userService.updateUser(item).subscribe( resp => {
    this.user = resp;
     // console.log("respuesta del servicio post updateUser:"+resp.toString());
  }, (err) => {
   
      console.log(err.error.error.message);
  });

  }*/
  
  getUserByEmail(email: string){
    this.userService.getUsuarioByEmail(email).subscribe(
      resp => {
        this.user = resp;
          //console.log("respuesta del servicio post:"+resp.toString());
      }, (err) => {
       
          console.log(err.error.error.message);
      });
  }

}
