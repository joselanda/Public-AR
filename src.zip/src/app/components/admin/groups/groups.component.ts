import { Component, OnInit, Query } from '@angular/core';
import { AfsService } from 'src/app/services/afs.service';
import { Observable } from 'rxjs';
import { AngularFirestore, AngularFirestoreCollection, AngularFirestoreDocument } from '@angular/fire/firestore';
import { ElementId, Elemento } from '../../../interfaces/element.interface';
import Swal from 'sweetalert2';
import { AuthService } from 'src/app/services/auth.service';
import { QueryFn } from '@angular/fire/firestore';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.css']
})
export class GroupsComponent implements OnInit {
  CARPETA_FILES = "groupsList";
  currentUser: ElementId = null;
  group: Elemento;
  groups: ElementId[] = [];
  isSupAdmin = false;
  isOwner = false;
  constructor(private afserv: AfsService, private afs: AngularFirestore, private authSvc: AuthService) { 
   
    this.currentUser = JSON.parse(localStorage.getItem("user"));
   
  }

  ngOnInit() {
    this.isSupAdmin = this.authSvc.isSupAdmin();
    this.isOwner = this.authSvc.isOwner(this.currentUser);
    console.log(JSON.stringify( this.currentUser));
    this.initGroupTemplate();
    console.log(this.group);
    
    //const query = (ref) => ref.where('type', "==", 'meximedia');
    this.afserv.col$('groups/'+this.currentUser.email.substring(0,10)+'/groups').subscribe(res => {
      console.log("res"+res);
      if (typeof res !== undefined) {
        this.groups = res as ElementId[];
        
      }
      console.log(this.groups);
    });

  }
  initGroupTemplate(){
    this.group = {
      name : "",
      description : "",
      password:""
    };
  }
  setCurrentItem(item: ElementId) {
    this.group = item;
    // console.log('CURRENTELEMENT: ', item);
  }

  addGroup(item: Elemento){
    let elemento = item as ElementId;
    elemento.id = this.currentUser.email.split('@')[0];
    elemento.name = item.name.replace(" ","");
    console.log("Grupo a guardar: "+ item.name.replace(" ","")+" JSON: "+ JSON.stringify(item));
    this.afserv.doc('profileTypes/'+item.name.replace(" ","")).set(elemento).then(res=>{
      console.log(JSON.stringify(res));
      elemento.password = "";
      elemento.url = 'groups/'+this.currentUser.email.split('@')[0]+'/groups/'+elemento.name;
      this.afserv.doc(elemento.url).set(elemento).then(res=>{
        
      }).catch(error=>{
      
      });
    }).catch(error=>{
     
    });
    document.getElementById('closeModal').click();
  }

}
