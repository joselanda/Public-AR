import { Component, OnInit, Input, Output, EventEmitter, OnChanges, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { ElementId } from 'src/app/interfaces/element.interface';
import Swal from 'sweetalert2';
import { NgForm } from '@angular/forms';
import { AuthService } from '../../../../services/auth.service';
import { Router } from '@angular/router';
import { FileModel } from 'src/app/models/file.model';
import { ElementsService } from 'src/app/services/elements.service';

@Component({
  selector: 'app-edit-element',
  templateUrl: './edit-element.component.html',
  styleUrls: ['./edit-element.component.css']
})
export class EditElementComponent implements OnInit, OnChanges, OnDestroy {
  ngOnDestroy(): void {
   // console.log("On destroy edit element");
  }
 
  @ViewChild('errDescription') errLbl: ElementRef;
  @Input() caller: string;
  @Input() item: ElementId;
  @Output() updateItem: EventEmitter<ElementId>;
  status: string = "habilitar";
  archivos: FileModel[] = [];
  currentElement:ElementId;
  templateElement: ElementId;

  constructor(private authService: AuthService,
    private router: Router, private elementService: ElementsService) {
      this.updateItem = new EventEmitter();
   }

  ngOnInit() {
    
  //console.log("NGONINIT edit element"+JSON.stringify(this.item));
  }
  ngOnChanges(changes: import("@angular/core").SimpleChanges): void {
    //console.log("onchanges: "+ JSON.stringify(changes));
        //throw new Error("Method not implemented.");
        this.errLbl.nativeElement.innerHTML = '';
    if (this.item != undefined) {
      
      this.currentElement = this.item;
      this.status = this.item.status ? "Deshabilitar" : "Habilitar";
     
      //this.ngOnInit();
      if (this.archivos.length == 0) {
        this.archivos = [];
        //this.item.images = [];
        //this.currentElement.images = [];
      }
    }
    else{
      //console.log("ENtrando a item nulo")
      this.item = {} as ElementId;
    }
            }
  onSubmit(form: NgForm) {
    this.errLbl.nativeElement.innerHTML = '';
    if ( form.invalid ) {
     // console.log("form invalid editelement: ");
      return;
    }
    if(this.currentElement.images != undefined)
    {
      if(this.currentElement.images.length <= 0){
        this.errLbl.nativeElement.innerHTML = 'Primero carga imagen';
      }else{
        this.updateItem.emit(this.currentElement);
        form.reset();
        this.borrarElementos();
      }
    }else if(this.currentElement.comments != undefined){
     console.log("element to send: "+JSON.stringify(this.currentElement));
      this.updateItem.emit(this.currentElement);
    }else{
      /*this.updateItem.emit(this.currentElement);
      form.reset();
      this.borrarElementos();*/
    }
  

  }
  borrarElementos() {
    let input = (<HTMLInputElement> document.getElementById("file"));
    input ? input.removeAttribute('value'): null;
    this.currentElement.images = null;
    //document.getElementById('file').removeAttribute('value');
    this.archivos = [];
    this.item.images = [];
  }
  cargarImagenes() {
    this.elementService.imagenUrl = true;
    this.item.images = this.elementService.cargarImagenesFirebase(this.archivos) as ElementId[];
    
    
  }
}
