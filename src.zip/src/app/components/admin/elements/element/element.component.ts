import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { ElementModel } from 'src/app/models/element.model';
import { NgForm } from '@angular/forms';
import { ElementsService } from 'src/app/services/elements.service';
import { FileModel } from '../../../../models/file.model';
import { ElementId } from 'src/app/interfaces/element.interface';


@Component({
  selector: 'app-element',
  templateUrl: './element.component.html',
  styleUrls: ['./element.component.css']
})
export class ElementComponent implements OnInit {

  estaSobreElemento = false;
  archivos: FileModel[] = [];
  element = new ElementModel();
  @Input() caller: string;
  @Output() addImage: EventEmitter<ElementId> ;
  constructor(private elementService: ElementsService) {
    this.addImage = new EventEmitter<ElementId>();
   }

  ngOnInit() {
  }
  borrarElementos() {
  this.archivos = [];
  }
  cargarImagenes() {
     this.elementService.cargarImagenesFirebase(this.archivos);
    /*if(file){
      console.log("EMITIENDO FILE INFO: "+JSON.stringify(file))
this.addImage.emit(file);
    }*/

  }

  

}
