export interface ElementsToAdd {
    name?: boolean;
    duration?: boolean;
    dateCreated?: boolean;
    dateModified?: boolean;
    title?: boolean;
    description?: boolean;
    type?: boolean;
    url?: boolean;
    email?: boolean;
    password?: boolean;
    tokn?: boolean;
    elements?: boolean;
    groups?: boolean;
    lists?: boolean;
    users?: boolean;
    products?: boolean;
    services?: boolean;
    phoneNumber?: boolean;
    displayName?: boolean;
    photoURL?: boolean;
    disabled?: boolean;
    emailVerified?: boolean;

}