import { Label } from "ng2-charts";
import { ChartDataSets } from "chart.js";
export interface Tile {
    index?: number;
    color?: string;
    cols?: number;
    rows?: number;
    text?: string;
    label?:string;
  }
export interface Elemento {
    name?: string;
    duration?: number;
    dateCreated?: Date;
    dateModified?: Date;
    title?: string;
    description?: string;
    type?: string;
    group?:string;
    url?: string;
    email?: string;
    password?: string;
    tokn?: string;
    images?: ElementId[];
    elements?: ElementId[];
    groups?: ElementId[];
    lists?: ElementId[];
    users?: ElementId[];
    products?: ElementId[];
    comments?: ElementId[];
    docs?: ElementId[];
    categories?:ElementId[];
    subcategories?: ElementId[];
    services?: ElementId[];
    phoneNumber?: string;
    displayName?: string;
    photoURL?: string;
    disabled?: boolean;
    emailVerified?: boolean;
    owner?: string;
    status?: boolean;
    total?: number;
    subtotal?: number;
    precioVta?: number;
    precioCompra?: number;
    hastags?:string[];
    areas?:ElementId[];
    address?: string;
    measure?: string;
    ventas?: number;
    vendor?: string;
    client?: string;
    stock?: number;
    imei?: number;
    barChartLabels?: Label[],
    barChartData?: ChartDataSets[],
    cantidad?: number,
    orden?:number,
    template?:ElementId


}

export interface ElementId extends Elemento { id?: string; uid?: string; }
export interface Template {
    id: string; 
    uid: string;
    name: string;
    duration: number;
    dateCreated: Date;
    dateModified: Date;
    title: string;
    description: string;
    type: string;
    url: string;
    email: string;
    password: string;
    tokn: string;
    images: ElementId[];
    elements: ElementId[];
    groups: ElementId[];
    lists: ElementId[];
    users: ElementId[];
    products: ElementId[];
    comments: ElementId[];
    docs: ElementId[];
    categories:ElementId[];
    subcategories: ElementId[];
    services: ElementId[];
    phoneNumber: string;
    displayName: string;
    photoURL: string;
    disabled: boolean;
    emailVerified: boolean;
    owner: string;
    status: boolean;
    total: number;
    subtotal: number;
    precioVta: number;
    precioCompra: number;
    hastags:string[];
    areas:ElementId[];
    address: string;
    measure: string;
    ventas: number;
    vendor: string;
    client: string;
    stock: number;
    imei: number;
    cantidad: number,
    orden:number


}