// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  serviceURL : "http://localhost:5000/apisvc/us-central1/api",
  firebase: {
    /*apiKey: 'AIzaSyBcPkO9oiGpfYaBUgfg2vsKvDdJdFYUOko',
    authDomain: 'publicastv-a67df.firebaseapp.com',
    databaseURL: 'https://publicastv-a67df.firebaseio.com',
    projectId: 'publicastv-a67df',
    storageBucket: 'publicastv-a67df.appspot.com',
    messagingSenderId: '1007974018930',
    appId: '1:1007974018930:web:0f3941663041e104'*/
    apiKey: "AIzaSyC-Dl8nAJlY_Po_IdFvBEuwcNxTC9ieG88",
    authDomain: "apisvc.firebaseapp.com",
    databaseURL: "https://apisvc.firebaseio.com",
    projectId: "apisvc",
    storageBucket: "apisvc.appspot.com",
    messagingSenderId: "115863732403",
    appId: "1:115863732403:web:21d4e74eb1ad83799ef0c6"
  },
  firebaseConfig : {
   apiKey: "AIzaSyBEYZHKcxCSAdhL62J-P4-kqobb4v4zFGY",
   authDomain: "italo-cf94a.firebaseapp.com",
   databaseURL: "https://italo-cf94a.firebaseio.com",
   projectId: "italo-cf94a",
   storageBucket: "italo-cf94a.appspot.com",
   messagingSenderId: "554998784947",
   appId: "1:554998784947:web:37a09e753617e4f826a1c6"
 }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
